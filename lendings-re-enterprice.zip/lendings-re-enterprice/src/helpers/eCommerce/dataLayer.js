export default function dataLayer(data) {
  window.dataLayer.push(data);
}
