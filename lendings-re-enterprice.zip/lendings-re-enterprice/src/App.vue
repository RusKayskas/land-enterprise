<template>
  <VueEnterprise />
</template>

<script setup>
  import VueEnterprise from './page/enterprise/index.vue';
</script>
