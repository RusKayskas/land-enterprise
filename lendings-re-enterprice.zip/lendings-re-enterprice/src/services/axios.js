import axios from 'axios';
export default class AxiosApi {
  constructor() {
    this.axios = axios;
  }
}
