<template>
  <VueRecaptcha sitekey="6Ldt3KUZAAAAACAVv1d5oFyMPOhcY6ddyqsRNKFp" />
</template>

<script setup>
  import { VueRecaptcha } from 'vue-recaptcha';
</script>
